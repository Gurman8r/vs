# BetterHewnFenceGates

Allow hewn fence gates to be placed in all cardinal directions
