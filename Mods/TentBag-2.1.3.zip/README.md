# TentBag

Adds a tent bag for Vintage Story

A mod based on the tentbag from jakecool19's [Useful Stuff](https://mods.vintagestory.at/show/mod/25) mod
