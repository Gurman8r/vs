# v1.4.0 - 2025-04-27 - VS Bug Work Around

## Compatibility with Other Mods

* #53 - Remove `skipVariants` with gold/silver from crafting recipes as this triggers a VS bug, resulting in uncraftable recipes

# v1.3.3 - 2025-04-12 - Compatibility

## Compatibility with Other Mods

* #52 - Add config setting to disable Food Shelves compatibility in case FS variants are used

# v1.3.2 - 2025-04-11 - Compatibility

## Bugfixes

* #50 - Fix 2x4 gate recipe

## Compatibility with Other Mods

* #51 - Add compatibility with Food Shelves (Thanx, Zach2039!)
* #50 - Fix compatibility with Wildcraft: Tree & Shrubs

# v1.3.1 - 2025-03-02 - Roped Recipes

## Bugfixes

* #46 - Crates needed specific variants of nails by accident
* #44 - Recipes needing clay could not use red clay

## New Features

* #48 - Crude doors need rope to craft (Thanx, Zach2039!)
* #40 - Recycle pulverizer caps back to metal bits
* #39 - Crafting leaded panes need hammer and shears

## Compatibility with Other Mods

* #47 - Patch Wool & More bucket recipe

# v1.3.0 - 2025-01-23 - More Nails

## New Features

* #37 - Wooden tables need nails & strips
* #36 - Wooden crates need nails & strips
* #28 - Wooden shelves need nails & strips
* #27 - Pulverizer frame needs hammer & nails

## Balancing and Tweaking

* #42 - Helvehammer needs two matching metal hoops, too
* #38 - Change support beam recipes to avoid confusion with planks-from-debarked logs recipe

## Compatibility with v1.20

* #41 - Fixes for VS 1.20

## Compatibility with Other Mods

* #43 - Remove Hide & Fabric compatibility

# v1.2.3 - 2024-08-29 - Wildcraft Trees

## Compatibility with Other Mods

* #34 - Update for Wildcraft: Trees and Shrubs 1.2.0 - remove crate & stump patches

# v1.2.2 - 2024-08-08 - Debarked Logs

## Bugfixes

* #32 - 3-tall doors recipe confliced with recipe for solid doors

## New Features

* #26 - Debarked logs can be sawn into boards
* #25 - Use debarked logs to craft axles, gears, pulverizes, pans etc.

## Compatibility with Other Mods

* #33 - Wildcraft: Trees and Shrubs stumps to log recipe requires an axe
* #25 - Compatibiliy for debarked logs from Wildcraft: Trees and Shrubs

# v1.2.1 - 2024-06-30 - Lanterns

## Bugfixes

* #22 - Fix solid doors with Wildcraft planks could not be crafted with all nail & strips variants

## New Features

* #20 - Basic lanterns need shears and hammer to craft

## Compatibility with Other Mods

* #23 - Crates made with Wildcraft: Tree wood types match VS crate recipes
* #21 - Compatibility recipes for Primitive Survival lanterns

# v1.2.0 - 2024-06-22 - More Strips & Nails

## Balancing and Tweaking

* #14 - Disallow gold and silver strips in some recipes

## New Features

* #45 - Patch recipe for buckets with rope
* #19 - Forge recipe takes small (hard) stones and clay
* #16 - Helve Hammers need matching strips & nails and a hammer

# v1.1.0 - 2024-06-19 - Recipe Tweaks

## New Features

* #13 - Brass torch holders needs a hammer
* #11 - Scroll rack crafting needs a hammer
* #10 - Metal plaque crafting needs a hammer

## Balancing and Tweaking

* #9 - Large troughs also require 4 sticks, and now 6 planks
* #8 - Buckets only use 3 planks

## Compatibility with Other Mods

* #12 - Wildcraft: Tree and Shrubs door recipes match new VS recipes

# v1.0.0 - 2024-06-18 - First Release

## New Features

* #7 - Fix handbook grouping of wood typed blocks
* #5 - Bloomeries need clay to "glue" the bricks together
* #4 - Iron doors need strips & nails and a hammer
* #3 - Barrels, buckets and troughs need strips & nails and a hammer
* #2 - Solid doors need strips & nails and a hammer
* #1 - Saws need flaxtwine and an additional stick

## Compatibility with Other Mods

* #3 - Hide and Fabric recipes match the new VS recipes
* #3 - Wildcraft: Tree and Shrubs recipes match the new VS recipes
* #2 - Group Wildcraft: Tree & Shrubs wood-typed doors in handbook

