# Vintage Recipes

This Vintage Story mod tweaks some crafting recipes to be more realistic.

We hope you enjoy our work.

~Phiwa & Tels

# Download

* The mod from [Official Vintage Story ModDB](https://mods.vintagestory.at/vintage_recipes)
* The source code can be found on [Gitlab](https://gitlab.com/codesmiths/vs_vintage_recipes/-/releases)

Vintage Recipes has optional config lib support, to use it, you need install these two mods:

* [Config lib](https://mods.vintagestory.at/configlib) (You need at least 1.3.13)
* [ImGui lib](https://mods.vintagestory.at/imgui)

If these two mods are not installed, the config file will be ignored and all tweaks
are enabled by default.

# Installation

This mod does not add new blocks, items nor does it change world generation. It
should be totally safe to add or remove this mod in existing worlds.

  <u>**Make a backup of your savegame and world before trying this mod!**</u>

If you would like to translate this mod into other languages, please [contact us](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/Contact).

# Configuration

If you change any of the settings in the `vintage_recipes.yaml` config file or via the
in-game GUI, you need to restart the server or reload the world for the settings
to become effective.

# Signature key

All our releases are signed using PGP (GnuPG) and their integrity can be verified by using the public key as published
[on the wiki](https://gitlab.com/codesmiths/vs_bricklayers/-/wikis/Signing-key).

