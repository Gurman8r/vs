This mod would have not been possible with the help of countless other people. We stand on the shoulders of giants!

Thank you,

~Tels & Phiwa

## Thank you

First and foremost a big thank you goes to **Saraty**, **Tyron** and all the other
team members for creating such a great game!

### Testing, Feedback and Bug Reporting

* **HoosierDaddy**
* **Maamessu**

### Contributors

* Food Shelves compatibility: **Zach2039**

### Translators

* German: **Tels**, **Phiwa**
* Japanese: **Macoto Hino**

### Modding help

* All the people answering (our and others) questions, on the modding-help discord channel or elsewere: You are awesome!
Especially:
  + **l33tmaan**
  + **Maltiez**
  + **SpearAndFang**

### Resources

The mod icon and title card image are based on generations from <https://aipixelartgenerator.com/>
