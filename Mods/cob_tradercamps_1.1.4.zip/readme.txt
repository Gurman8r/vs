=========================================================================
Presented by "CONQUEST OF BLOCKS" - Multiplayer server for Vintage Story.
=========================================================================

Website: www.vintagestory.online
Discord: discord.gg/jbVQTd3h77

Mod description:
In the vanilla game, traders can mostly be found as lone wolves somewhere in the wild. 
With this mod, traders will more often hang out together in small camps. Single traders will 
still be available, but less often.


This version of our server mod is free to use on any other multiplayer server.
Your clients do not need to download this mod. It's server side only.


HOW TO MODIFY:
==============
The mod will generate a "TraderCamps.json" in your ModConfig folder.

"TraderCampSetup":

1 (medium density, claimed)
2 (medium density, unclaimed)
3 (high density, claimed)
4 (high density, unclaimed)
5 (low density, claimed)
6 (low density, unclaimed)


"LoneTraderSetup":

1 (rare, claimed)
2 (rare, unclaimed)
3 (common, claimed)
4 (common, unclaimed)