Shark assets created by Radiomann01 for the purposes of this mod.

Shark attack.ogg base sample provided by Floraphonic through Pixabay.

Version updated to 1.2.4
Collated creatureitems into one creatures.json file (Thanks to RogueRaiden on the Discord for doing this for me!!)

Version updated to 1.2.3
Adjusted some spawn logic to make more sense (I think).
Added modid to modinfo.json

Version updated to 1.2.2
Re-readjusted spawn rates. No idea how this'll go!
Adjusted shark aggressiveness vs seraphs; They should only attack when attacked first. At some point we'll add in more suitable always-hostile enemies, probably mechanical themed.
Made sharks drop 16 fish meat because lord knows getting fish meat in vanilla is a chore.
Greatly expanded the temperature range sharks show up in.
Sharks do 12 damage now.

Version updated to 1.2.1
Cut spawning rates by 10 times at least for all critters, they were WAY too high.
Fixed null texture error on sunfish.

Version updated to 1.2
Added Ocean Sunfish and Moon Jellyfish.
Tweaked sharks so that they can actually consistently damage other entities.